Cs = 1361 ;%Solar constant
A =0.35; %Albedo (effect of the albedo in sun sensors
%%

low_sat = 0.5; %Lower limit saturation sensor [W/m2]
up_sat = 1e4; %Upper limit saturation sensor [W/m2]

var = 1e-4; %Noise variance of sun sensors